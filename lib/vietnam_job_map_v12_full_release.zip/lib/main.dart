import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';

void main() => runApp(const MaterialApp(home: RoleScreen(), debugShowCheckedModeBanner: false));

// ================= 1. 身分選擇引導入口 =================
class RoleScreen extends StatefulWidget {
  const RoleScreen({Key? key}) : super(key: key);
  @override State<RoleScreen> createState() => _RoleScreenState();
}

class _RoleScreenState extends State<RoleScreen> {
  String _lang = 'zh';

  @override Widget build(BuildContext context) {
    final isZh = _lang == 'zh';
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF064E3B), Color(0xFF0F172A), Color(0xFF020617)]),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                  ActionChip(
                    backgroundColor: Colors.white12,
                    label: Text(isZh ? '🇻🇳 Tiếng Việt' : '🇹🇼 繁體中文', style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, fontSize: 12)),
                    onPressed: () => setState(() => _lang = isZh ? 'vi' : 'zh'),
                  ),
                ]),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: const Color(0xFF008848), shape: BoxShape.circle, border: Border.all(color: Colors.amber, width: 2), boxShadow: const [BoxShadow(color: Color(0xFF008848), blurRadius: 20)]),
                  child: const Text('🌿', style: TextStyle(fontSize: 36)),
                ),
                const SizedBox(height: 12),
                const Text('Việc Làm Bản Đồ', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.black, letterSpacing: 0.5)),
                Text(isZh ? '越南在地地圖求職 • 大廠即時連線' : 'Tìm việc bản đồ • Kết nối TopCV & Mạng XH', style: const TextStyle(color: Color(0xFFFCD34D), fontSize: 12)),
                const SizedBox(height: 24),
                _roleCard(
                  isWorker: true,
                  title: isZh ? '👤 我是求職者 (Người tìm việc)' : '👤 Tôi là Người tìm việc',
                  desc: isZh ? '地圖找大廠職缺、薪資透明拆解、查看公司評價' : 'Xem việc quanh bạn, lương minh bạch, đánh giá',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MainApp(role: 'WORKER', initialLang: _lang))),
                ),
                const SizedBox(height: 14),
                _roleCard(
                  isWorker: false,
                  title: isZh ? '🏢 我是招聘企業 (Nhà tuyển dụng)' : '🏢 Tôi là Nhà tuyển dụng',
                  desc: isZh ? '地圖搜尋周邊人才、審核工作歷史穩定度' : 'Tìm ứng viên quanh bạn, xem độ ổn định, Zalo/FB',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MainApp(role: 'EMPLOYER', initialLang: _lang))),
                ),
                const Spacer(),
                const Text('🔗 支援 TopCV • VietnamWorks • Việc Làm 24h 即時更新', style: TextStyle(color: Colors.white60, fontSize: 10.5)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _roleCard({required bool isWorker, required String title, required String desc, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: double.infinity, padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), border: Border.all(color: isWorker ? const Color(0xFF10B981) : const Color(0xFF3B82F6), width: 2), borderRadius: BorderRadius.circular(20)),
        child: Row(children: [
          CircleAvatar(backgroundColor: isWorker ? const Color(0xFF008848) : const Color(0xFF1E40AF), child: Text(isWorker ? '👤' : '🏢', style: const TextStyle(fontSize: 20))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13.5)),
            const SizedBox(height: 2),
            Text(desc, style: const TextStyle(color: Colors.white70, fontSize: 10.5)),
          ])),
        ]),
      ),
    );
  }
}

// ================= 2. 主應用與多功能狀態管理 =================
class MainApp extends StatefulWidget {
  final String role;
  final String initialLang;
  const MainApp({Key? key, required this.role, required this.initialLang}) : super(key: key);
  @override State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  int _tab = 0;
  late String _lang;
  late String _role;
  LatLng _userLocation = const LatLng(10.8231, 106.6297);
  bool _isLocating = false;
  bool _isSyncing = false;
  String _selectedCategory = 'ALL';

  // 越南六大標準招募分類
  final Map<String, Map<String, String>> _categories = {
    'ALL': {'zh': '全部職缺', 'vi': 'Tất cả'},
    'MFG': {'zh': '🏭 製造加工', 'vi': '🏭 Sản xuất'},
    'LOG': {'zh': '📦 倉儲物流', 'vi': '📦 Kho vận'},
    'FNB': {'zh': '☕ 餐飲門市', 'vi': '☕ F&B / Nhà hàng'},
    'RET': {'zh': '🛒 零售超商', 'vi': '🛒 Bán lẻ'},
    'ADM': {'zh': '🏢 行政財務', 'vi': '🏢 Văn phòng'},
    'SEC': {'zh': '🛡️ 保全技術', 'vi': '🛡️ Kỹ thuật'},
  };

  // 越南主要工業區與行政區下拉選單選項
  final List<Map<String, dynamic>> _locations = [
    {'name_zh': '平陽省 順安市 VSIP 1 工業區', 'name_vi': 'KCN VSIP 1, Thuận An, Bình Dương', 'lat': 10.9315, 'lng': 106.6980},
    {'name_zh': '平陽省 宜安市 神浪 2 工業區', 'name_vi': 'KCN Sóng Thần 2, Dĩ An, Bình Dương', 'lat': 10.9050, 'lng': 106.7450},
    {'name_zh': '胡志明市 新平工業區 (新平/新富)', 'name_vi': 'KCN Tân Bình, TP. Hồ Chí Minh', 'lat': 10.8120, 'lng': 106.6280},
    {'name_zh': '胡志明市 第一郡 商業區', 'name_vi': 'Quận 1, TP. Hồ Chí Minh', 'lat': 10.7825, 'lng': 106.6992},
    {'name_zh': '同奈省 邊和市 邊和 2 工業區', 'name_vi': 'KCN Biên Hòa 2, Đồng Nai', 'lat': 10.9520, 'lng': 106.8650},
    {'name_zh': '同奈省 隆城 Amata 工業區', 'name_vi': 'KCN Amata, Đồng Nai', 'lat': 10.9400, 'lng': 106.8900},
  ];

  // 即時職缺數據庫 (支援大廠同步與企業自發布)
  List<Map<String, dynamic>> _jobs = [
    {
      'id': 'job1',
      'category': 'LOG',
      'source': 'TopCV 連線 (MST: 3702849102)',
      'url': 'https://www.topcv.vn/viec-lam/vsip-logistics',
      'zalo': 'https://zalo.me/g/vsip_tuyendung',
      'fb': 'https://facebook.com/groups/kcn.binhduong.job',
      'tz': '堆高機司機兼倉儲理貨組長', 'tv': 'Tài xế Lái Xe Nâng & Kho',
      'cz': '平陽 VSIP 1 國際物流大廠', 'cv': 'Logistics VSIP 1 Bình Dương',
      'sz': '11 - 15.5 百萬/月 (約1.4~2.0萬台幣)', 'sv': '11 - 15.5 tr/tháng',
      'b': '7.5M底薪 + 3.5M津貼 (包吃住)', 'r': '4.9★ (68則評價, 100%發薪準時)',
      'cand': '阮文雄 (Nguyễn Văn Hùng)', 'stab': '96分 (平均任職2.1年, 0跳槽)',
      'lat': 10.9315, 'lng': 106.6980,
      'logo': 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=120',
      'ava': 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120',
      'isNew': false,
    },
    {
      'id': 'job2',
      'category': 'MFG',
      'source': 'VietnamWorks 連線 (MST: 0301984712)',
      'url': 'https://www.vietnamworks.com/viec-lam/tan-binh-textile',
      'zalo': 'https://zalo.me/g/tanbinh_garment',
      'fb': 'https://facebook.com/kcntanbinh.tuyendung',
      'tz': '成衣工廠車縫熟手 (平車/拷克)', 'tv': 'Thợ May 1 Kim/Vắt Sổ',
      'cz': '新平工業區成衣外銷大廠 (胡志明市)', 'cv': 'CP Dệt May Tân Bình',
      'sz': '8.5 - 13 百萬/月 (約1.1~1.7萬台幣)', 'sv': '8.5 - 13 tr/tháng',
      'b': '6.0M底薪 + 2.5M津貼 (供中餐+年終)', 'r': '4.7★ (114則評價, 99%發薪準時)',
      'cand': '陳氏梅 (Trần Thị Mai)', 'stab': '91分 (平均任職1.9年, 熟手)',
      'lat': 10.8120, 'lng': 106.6280,
      'logo': 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=120',
      'ava': 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120',
      'isNew': false,
    },
    {
      'id': 'job3',
      'category': 'MFG',
      'source': 'Việc Làm 24h 連線 (MST: 3709182314)',
      'url': 'https://vieclam24h.vn/co-khi-song-than-2',
      'zalo': 'https://zalo.me/g/songthan2_cnc',
      'fb': 'https://facebook.com/groups/cokhibinhduong',
      'tz': '精密機械加工與CNC/焊接技術工', 'tv': 'Kỹ Thuật Viên Hàn TIG/CNC',
      'cz': '神浪 2 工業區精密機械廠 (平陽省)', 'cv': 'Cơ Khí Sóng Thần 2',
      'sz': '12 - 17 百萬/月 (約1.5~2.2萬台幣)', 'sv': '12 - 17 tr/tháng',
      'b': '8.5M底薪 + 3.5M津貼 (包早午餐)', 'r': '4.8★ (52則評價, 生產獎金)',
      'cand': '黎文南 (Lê Văn Nam)', 'stab': '88分 (平均任職1.7年, 氬焊證)',
      'lat': 10.9050, 'lng': 106.7450,
      'logo': 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=120',
      'ava': 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120',
      'isNew': false,
    },
  ];

  // 待同步之大廠數據庫緩存池
  final List<Map<String, dynamic>> _incomingExternalJobs = [
    {
      'id': 'ext1',
      'category': 'MFG',
      'source': 'TopCV 即時同步 (MST: 3600282811)',
      'url': 'https://topcv.vn/pouchen-dongnai',
      'zalo': 'https://zalo.me/g/pouchen_tuyendung',
      'fb': 'https://facebook.com/groups/pouchen.dongnai',
      'tz': '寶元鞋業 (Pou Chen) 製鞋流水線品檢員', 'tv': 'KCS / Kiểm tra chất lượng Giày PouChen',
      'cz': '寶成集團 同奈邊和廠區 (萬人大廠)', 'cv': 'Tập Đoàn Pou Chen Đồng Nai',
      'sz': '9.5 - 14.5 百萬/月 (約1.2~1.9萬台幣)', 'sv': '9.5 - 14.5 tr/tháng',
      'b': '6.8M底薪 + 2.8M津貼 + 每年調薪', 'r': '4.8★ (320則大廠評價, 發薪準時100%)',
      'cand': '武文雄 (Vũ Văn Hùng)', 'stab': '94分 (平均任職2.5年)',
      'lat': 10.9520, 'lng': 106.8650,
      'logo': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=120',
      'ava': 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120',
      'isNew': true,
    },
    {
      'id': 'ext2',
      'category': 'FNB',
      'source': 'VietnamWorks 即時同步 (MST: 0312345678)',
      'url': 'https://vietnamworks.com/highlands-coffee',
      'zalo': 'https://zalo.me/highlands_careers',
      'fb': 'https://facebook.com/highlandscoffeevietnam',
      'tz': 'Highlands Coffee 門市儲備店長/調飲師', 'tv': 'Barista & Quản lý Highlands Coffee',
      'cz': 'Highlands Coffee 旗艦連鎖體系 (第一郡)', 'cv': 'Chuỗi Highlands Coffee TP.HCM',
      'sz': '8.0 - 11.5 百萬/月 (約1.0~1.5萬台幣)', 'sv': '8.0 - 11.5 tr/tháng',
      'b': '6.5M底薪 + 門市業績抽成 + 員工飲品免費', 'r': '4.9★ (410則評價, 連鎖制度完善)',
      'cand': '黃秋莊 (Hoàng Thu Trang)', 'stab': '92分 (平均任職2.0年)',
      'lat': 10.7825, 'lng': 106.6992,
      'logo': 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=120',
      'ava': 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120',
      'isNew': true,
    },
  ];

  // 儲存表單的控制器與下拉變數
  final _cvNameController = TextEditingController(text: '阮文雄 (Nguyễn Văn Hùng)');
  final _cvSalaryController = TextEditingController(text: '10,000,000 - 13,500,000 VNĐ');
  final _cvZaloController = TextEditingController(text: 'zalo.me/0901234567');
  String _cvSelectedCategory = 'LOG';
  int _cvSelectedLocationIndex = 0;

  final _postTitleController = TextEditingController();
  final _postSalaryController = TextEditingController();
  final _postZaloController = TextEditingController();
  String _postSelectedCategory = 'MFG';
  int _postSelectedLocationIndex = 0;

  @override void initState() {
    super.initState();
    _lang = widget.initialLang;
    _role = widget.role;
    _locateGPS();
  }

  Future<void> _locateGPS() async {
    setState(() => _isLocating = true);
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.whileInUse || permission == LocationPermission.always) {
        var pos = await Geolocator.getCurrentPosition();
        setState(() => _userLocation = LatLng(pos.latitude, pos.longitude));
      }
    } catch (_) {}
    setState(() => _isLocating = false);
  }

  // 即時連線刷新大數據庫
  Future<void> _syncExternalJobDatabase() async {
    setState(() => _isSyncing = true);
    await Future.delayed(const Duration(seconds: 2)); // 模擬即時網路連線

    setState(() {
      for (var extJob in _incomingExternalJobs) {
        if (!_jobs.any((j) => j['id'] == extJob['id'])) {
          _jobs.insert(0, Map<String, dynamic>.from(extJob));
        }
      }
      _isSyncing = false;
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_lang == 'zh' ? '✅ 成功連線 TopCV 與 VietnamWorks，已即時同步導入最新大廠職缺！' : '✅ Đã đồng bộ việc làm mới từ TopCV & VietnamWorks!'),
          backgroundColor: const Color(0xFF008848),
        ),
      );
    }
  }

  // 企業發布職缺 (真正儲存至資料庫與地圖)
  void _saveNewJobPosting() {
    if (_postTitleController.text.trim().isEmpty || _postSalaryController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_lang == 'zh' ? '請填寫職缺名稱與薪資範圍！' : 'Vui lòng điền tiêu đề và mức lương!'), backgroundColor: Colors.red),
      );
      return;
    }

    final loc = _locations[_postSelectedLocationIndex];
    final newJob = {
      'id': 'user_job_${DateTime.now().millisecondsSinceEpoch}',
      'category': _postSelectedCategory,
      'source': _lang == 'zh' ? '在地企業直發 (已驗證)' : 'Doanh nghiệp đăng trực tiếp',
      'url': 'https://zalo.me',
      'zalo': _postZaloController.text.isNotEmpty ? _postZaloController.text : 'zalo.me/0909998877',
      'fb': 'https://facebook.com',
      'tz': _postTitleController.text.trim(),
      'tv': _postTitleController.text.trim(),
      'cz': loc['name_zh'],
      'cv': loc['name_vi'],
      'sz': '${_postSalaryController.text.trim()} (企業直聘)',
      'sv': '${_postSalaryController.text.trim()} (DN đăng)',
      'b': _lang == 'zh' ? '底薪+津貼保障 (供餐/宿舍/勞保)' : 'Lương CB + Phụ cấp đầy đủ',
      'r': '5.0★ (在地直聘新發布)',
      'cand': _lang == 'zh' ? '招募中' : 'Đang tuyển',
      'stab': '95分',
      'lat': loc['lat'] as double,
      'lng': loc['lng'] as double,
      'logo': 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=120',
      'ava': 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120',
      'isNew': true,
    };

    setState(() {
      _jobs.insert(0, newJob);
      _postTitleController.clear();
      _postSalaryController.clear();
      _postZaloController.clear();
      _tab = 0; // 自動切換回地圖檢視
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_lang == 'zh' ? '🎉 職缺已成功發布並即時釘選至地圖！' : '🎉 Đã đăng tin tuyển dụng lên bản đồ thành công!'),
        backgroundColor: const Color(0xFF1E40AF),
      ),
    );
  }

  // 求職者儲存履歷
  void _saveWorkerCv() {
    setState(() {
      // 成功儲存履歷
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_lang == 'zh' ? '✅ 履歷已成功儲存！大廠與周邊企業已可在地圖搜尋到您。' : '✅ Đã lưu hồ sơ thành công!'),
        backgroundColor: const Color(0xFF008848),
      ),
    );
  }

  List<Map<String, dynamic>> get _filteredJobs {
    if (_selectedCategory == 'ALL') return _jobs;
    return _jobs.where((j) => j['category'] == _selectedCategory).toList();
  }

  @override Widget build(BuildContext context) {
    final isZh = _lang == 'zh';
    final isWorker = _role == 'WORKER';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: isWorker ? const Color(0xFF008848) : const Color(0xFF1E40AF),
        foregroundColor: Colors.white,
        title: Text(isWorker ? (isZh ? '👤 求職者模式 (找工作)' : '👤 Người tìm việc') : (isZh ? '🏢 企業招聘模式 (找人才)' : '🏢 Nhà tuyển dụng'), style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: isZh ? '即時同步大廠職缺' : 'Đồng bộ dữ liệu',
            icon: _isSyncing ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.amber, strokeWidth: 2)) : const Icon(Icons.sync, color: Colors.amberAccent),
            onPressed: _isSyncing ? null : _syncExternalJobDatabase,
          ),
          TextButton(onPressed: () => setState(() => _lang = isZh ? 'vi' : 'zh'), child: Text(isZh ? '🇻🇳' : '🇹🇼', style: const TextStyle(fontSize: 18))),
          IconButton(icon: const Icon(Icons.logout), onPressed: () => Navigator.pop(context)),
        ],
      ),
      body: Column(
        children: [
          // 頂部大類水平滑動篩選條 (六大標準行業分類)
          Container(
            height: 44,
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: _categories.entries.map((entry) {
                final isSelected = _selectedCategory == entry.key;
                return Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(
                    label: Text(isZh ? entry.value['zh']! : entry.value['vi']!, style: TextStyle(fontSize: 11, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal, color: isSelected ? Colors.white : Colors.black87)),
                    selected: isSelected,
                    selectedColor: isWorker ? const Color(0xFF008848) : const Color(0xFF1E40AF),
                    onSelected: (_) => setState(() => _selectedCategory = entry.key),
                  ),
                );
              }).toList(),
            ),
          ),
          Expanded(
            child: _tab == 0 ? _buildMapView(isZh, isWorker) : (_tab == 1 ? _buildListView(isZh, isWorker) : (isWorker ? _buildCvTab(isZh) : _buildPostTab(isZh))),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.map), label: isZh ? (isWorker ? '地圖職缺' : '地圖人才') : 'Bản đồ'),
          NavigationDestination(icon: const Icon(Icons.auto_awesome), label: isZh ? '推薦列表' : 'Gợi ý'),
          NavigationDestination(icon: Icon(isWorker ? Icons.person : Icons.post_add), label: isZh ? (isWorker ? '我的履歷' : '發布職缺') : 'Hồ sơ'),
        ],
      ),
    );
  }

  // ================= 3. 地圖檢視 (含定位與圖釘頭像/LOGO) =================
  Widget _buildMapView(bool isZh, bool isWorker) {
    final jobs = _filteredJobs;
    return Stack(
      children: [
        FlutterMap(
          options: MapOptions(initialCenter: _userLocation, initialZoom: 12),
          children: [
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'vn.vieclambando.app'),
            MarkerLayer(
              markers: [
                Marker(point: _userLocation, width: 30, height: 30, child: const Icon(Icons.my_location, color: Colors.red, size: 28)),
                ...jobs.map((j) => Marker(
                  point: LatLng(j['lat'], j['lng']),
                  width: 155,
                  height: 44,
                  child: GestureDetector(
                    onTap: () => _showModalDetail(j, isZh, isWorker),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                      decoration: BoxDecoration(
                        color: isWorker ? const Color(0xFF008848) : const Color(0xFF1E40AF),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: j['isNew'] == true ? Colors.amberAccent : Colors.white, width: 2),
                        boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 6)],
                      ),
                      child: Row(
                        children: [
                          ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.network(isWorker ? j['logo'] : j['ava'], width: 26, height: 26, fit: BoxFit.cover)),
                          const SizedBox(width: 5),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(isWorker ? (isZh ? j['tz'] : j['tv']) : j['cand'], style: const TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
                                Text(isWorker ? j['sz'].split(' ')[0] + 'M' : j['stab'], style: const TextStyle(color: Colors.amberAccent, fontSize: 8.5, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )).toList(),
              ],
            ),
          ],
        ),
        // 頂部大廠連線提示按鈕
        Positioned(
          top: 8, left: 10, right: 10,
          child: InkWell(
            onTap: _syncExternalJobDatabase,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)]),
              child: Row(
                children: [
                  const Text('🔄', style: TextStyle(fontSize: 12)),
                  const SizedBox(width: 6),
                  Expanded(child: Text(isZh ? '點此即時同步 TopCV / VietnamWorks 最新大廠數據' : 'Chạm để đồng bộ TopCV & VNW mới nhất', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.indigo))),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: Colors.amber.shade100, borderRadius: BorderRadius.circular(6)), child: Text('${jobs.length} 筆', style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold, color: Colors.brown))),
                ],
              ),
            ),
          ),
        ),
        // GPS 定位懸浮按鈕
        Positioned(
          right: 16, bottom: 16,
          child: FloatingActionButton(
            mini: true,
            backgroundColor: Colors.white,
            onPressed: _locateGPS,
            child: _isLocating ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.gps_fixed, color: Color(0xFF008848)),
          ),
        ),
      ],
    );
  }

  // ================= 4. 職缺與人才列表檢視 =================
  Widget _buildListView(bool isZh, bool isWorker) {
    final jobs = _filteredJobs;
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: jobs.length,
      itemBuilder: (ctx, i) {
        final j = jobs[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 2,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(isWorker ? j['logo'] : j['ava'], width: 44, height: 44, fit: BoxFit.cover)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5), decoration: BoxDecoration(color: Colors.amber.shade100, borderRadius: BorderRadius.circular(4)), child: Text(j['source'], style: const TextStyle(fontSize: 9, color: Colors.brown, fontWeight: FontWeight.bold))),
                              const Spacer(),
                              if (j['isNew'] == true) Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5), decoration: BoxDecoration(color: Colors.red.shade100, borderRadius: BorderRadius.circular(4)), child: const Text('MỚI / 最新', style: TextStyle(fontSize: 8.5, color: Colors.red, fontWeight: FontWeight.bold))),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(isWorker ? (isZh ? j['tz'] : j['tv']) : j['cand'], style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                          Text(isWorker ? (isZh ? j['cz'] : j['cv']) : '📍 工業區人才庫', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(color: isWorker ? Colors.amber.shade50 : Colors.blue.shade50, borderRadius: BorderRadius.circular(8)),
                  child: Text(isWorker ? '⭐ ${j['r']} • 💰 ${j['b']}' : '🛡️ 穩定度評分：${j['stab']}', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, color: isWorker ? Colors.brown : Colors.blue.shade900)),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(isWorker ? (isZh ? j['sz'] : j['sv']) : '期望 10~13.5M', style: const TextStyle(color: Color(0xFF008848), fontWeight: FontWeight.bold, fontSize: 12)),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: isWorker ? const Color(0xFF008848) : const Color(0xFF1E40AF), foregroundColor: Colors.white),
                      onPressed: () => _showModalDetail(j, isZh, isWorker),
                      child: Text(isWorker ? (isZh ? '查看與應徵' : 'Chi tiết') : (isZh ? '邀請面試' : 'Mời PV')),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ================= 5. 詳細資訊彈窗 (含社群直連與大廠原站連結) =================
  void _showModalDetail(Map<String, dynamic> j, bool isZh, bool isWorker) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(isWorker ? j['logo'] : j['ava'], width: 44, height: 44, fit: BoxFit.cover)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(j['source'], style: const TextStyle(fontSize: 10, color: Colors.amber, fontWeight: FontWeight.bold)),
                      Text(isWorker ? (isZh ? j['tz'] : j['tv']) : j['cand'], style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                      Text(isWorker ? (isZh ? j['cz'] : j['cv']) : '📍 工業區已驗證經歷', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: isWorker ? Colors.amber.shade50 : Colors.blue.shade50, borderRadius: BorderRadius.circular(10)),
              child: Text(isWorker ? '⭐ ${j['r']} • 💰 ${j['b']}' : '🛡️ 穩定度分析：${j['stab']}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: isWorker ? Colors.brown : Colors.blue.shade900)),
            ),
            const SizedBox(height: 10),
            // 社群與大廠公開連結按鈕
            Wrap(
              spacing: 8,
              children: [
                ActionChip(
                  avatar: const Text('💬'),
                  backgroundColor: Colors.blue.shade50,
                  label: const Text('Zalo 私訊', style: TextStyle(color: Colors.blue, fontSize: 10.5, fontWeight: FontWeight.bold)),
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('已開啟 Zalo: ${j['zalo']}'))),
                ),
                ActionChip(
                  avatar: const Text('🌐'),
                  backgroundColor: Colors.indigo.shade50,
                  label: const Text('Facebook 群組', style: TextStyle(color: Colors.indigo, fontSize: 10.5, fontWeight: FontWeight.bold)),
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('已開啟 FB: ${j['fb']}'))),
                ),
                ActionChip(
                  avatar: const Text('🔗'),
                  backgroundColor: Colors.orange.shade50,
                  label: const Text('原始徵才網站來源', style: TextStyle(color: Colors.deepOrange, fontSize: 10.5, fontWeight: FontWeight.bold)),
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('已連線至: ${j['url']}'))),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(isWorker ? (isZh ? j['sz'] : j['sv']) : '期望月薪 10~13.5M', style: const TextStyle(color: Color(0xFF008848), fontWeight: FontWeight.bold, fontSize: 12.5)),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: isWorker ? const Color(0xFF008848) : const Color(0xFF1E40AF), foregroundColor: Colors.white),
                  onPressed: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(isWorker ? '應徵成功！已同步至大廠人資系統。' : '面試邀請已發送！')));
                  },
                  child: Text(isWorker ? '立即應徵' : '邀請面試'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ================= 6. 求職者履歷分頁 (含下拉選單與儲存) =================
  Widget _buildCvTab(bool isZh) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(isZh ? '我的結構化履歷 (CV)' : 'Hồ Sơ Năng Lực', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: _cvNameController, decoration: InputDecoration(labelText: isZh ? '姓名 / Họ tên' : 'Họ và tên', border: const OutlineInputBorder())),
        const SizedBox(height: 10),
        // 專長大類下拉選單
        DropdownButtonFormField<String>(
          value: _cvSelectedCategory,
          decoration: InputDecoration(labelText: isZh ? '專長行業類別 (下拉選擇)' : 'Ngành nghề chuyên môn', border: const OutlineInputBorder()),
          items: _categories.entries.where((e) => e.key != 'ALL').map((e) => DropdownMenuItem(value: e.key, child: Text(isZh ? e.value['zh']! : e.value['vi']!))).toList(),
          onChanged: (val) => setState(() => _cvSelectedCategory = val!),
        ),
        const SizedBox(height: 10),
        // 期望工作區域下拉選單
        DropdownButtonFormField<int>(
          value: _cvSelectedLocationIndex,
          decoration: InputDecoration(labelText: isZh ? '期望工作省市/工業區 (下拉選擇)' : 'Khu vực làm việc mong muốn', border: const OutlineInputBorder()),
          items: List.generate(_locations.length, (idx) => DropdownMenuItem(value: idx, child: Text(isZh ? _locations[idx]['name_zh'] : _locations[idx]['name_vi'], style: const TextStyle(fontSize: 12)))),
          onChanged: (val) => setState(() => _cvSelectedLocationIndex = val!),
        ),
        const SizedBox(height: 10),
        TextField(controller: _cvSalaryController, decoration: InputDecoration(labelText: isZh ? '期望月薪 / Lương kỳ vọng' : 'Mức lương kỳ vọng', border: const OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: _cvZaloController, decoration: InputDecoration(labelText: isZh ? '社群連結 / Zalo, Facebook (選填)' : 'Link Zalo / Facebook', border: const OutlineInputBorder())),
        const SizedBox(height: 12),
        Card(
          color: Colors.grey.shade50,
          child: const Padding(
            padding: EdgeInsets.all(10),
            child: Text('💼 歷史工作時間：平陽神浪倉儲 (2年3個月) • 同奈 Amata (1年8個月) • 供企業審核穩定度 (求職者端不顯示扣分)', style: TextStyle(fontSize: 11)),
          ),
        ),
        const SizedBox(height: 14),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF008848), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12)),
          onPressed: _saveWorkerCv,
          child: Text(isZh ? '儲存履歷並開啟求職' : 'Lưu Hồ Sơ & Bật Tìm Việc', style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
      ],
    );
  }

  // ================= 7. 企業發布職缺分頁 (含下拉選單與真正儲存) =================
  Widget _buildPostTab(bool isZh) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(isZh ? '發布職缺至地圖 (企業端)' : 'Đăng Tin Tuyển Dụng', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: _postTitleController, decoration: InputDecoration(labelText: isZh ? '職缺名稱 / Vị trí tuyển dụng' : 'Vị trí tuyển dụng', hintText: '例：堆高機熟手 / 成衣車縫工', border: const OutlineInputBorder())),
        const SizedBox(height: 10),
        // 職缺分類下拉選單
        DropdownButtonFormField<String>(
          value: _postSelectedCategory,
          decoration: InputDecoration(labelText: isZh ? '職缺所屬分類 (下拉選擇)' : 'Phân loại ngành nghề', border: const OutlineInputBorder()),
          items: _categories.entries.where((e) => e.key != 'ALL').map((e) => DropdownMenuItem(value: e.key, child: Text(isZh ? e.value['zh']! : e.value['vi']!))).toList(),
          onChanged: (val) => setState(() => _postSelectedCategory = val!),
        ),
        const SizedBox(height: 10),
        // 廠區所在省市/工業區下拉選單
        DropdownButtonFormField<int>(
          value: _postSelectedLocationIndex,
          decoration: InputDecoration(labelText: isZh ? '廠區所在工業區/地址 (下拉選擇)' : 'Địa điểm KCN làm việc', border: const OutlineInputBorder()),
          items: List.generate(_locations.length, (idx) => DropdownMenuItem(value: idx, child: Text(isZh ? _locations[idx]['name_zh'] : _locations[idx]['name_vi'], style: const TextStyle(fontSize: 12)))),
          onChanged: (val) => setState(() => _postSelectedLocationIndex = val!),
        ),
        const SizedBox(height: 10),
        TextField(controller: _postSalaryController, decoration: InputDecoration(labelText: isZh ? '薪資範圍 / Khung lương' : 'Khung lương', hintText: '例：10 - 14 百萬/月', border: const OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: _postZaloController, decoration: InputDecoration(labelText: isZh ? '企業社群 / Zalo OA, Fanpage (選填)' : 'Zalo OA / Fanpage tuyển dụng', border: const OutlineInputBorder())),
        const SizedBox(height: 14),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1E40AF), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12)),
          onPressed: _saveNewJobPosting,
          child: Text(isZh ? '立即發布職缺並釘選至地圖' : 'Đăng Tin Lên Bản Đồ Ngay', style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
      ],
    );
  }
}
